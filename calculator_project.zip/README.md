# Calculator 🧮

A simple web-based calculator built using HTML, CSS, and JavaScript. This calculator supports basic arithmetic operations along with modulus (%) and power (^).

## 🚀 Features

- Basic operations: `+`, `-`, `×`, `÷`
- Advanced: `%`, `^` (power)
- Clear input (`AC`) and calculate result (`=`)
- Responsive layout using CSS Grid and Bootstrap

## 📷 Screenshot

![Calculator Screenshot](screenshot.png)

## 🛠️ How to Use

1. Clone the repository or download the code.
2. Open the `index.html` file in your browser.
3. Start calculating!

## 🗂 Folder Structure

```
calculator/
├── index.html
├── script.js
├── style.css
└── README.md
```

## ✨ Demo

You can also deploy it via GitHub Pages:
```
https://<your-username>.github.io/calculator/
```

## 📌 Note

This project uses `eval()` for simplicity. In a production environment, it’s recommended to replace this with a safer parser like [math.js](https://mathjs.org/).
