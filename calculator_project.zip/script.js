let display = document.getElementById("display");

function appendToDisplay(value) {
    display.value += value;
}

function clearDisplay() {
    display.value = "";
}

function calculateResult() {
    try {
        if (display.value.trim() === "") {
            display.value = "Enter a value";
        } else {
            const expression = display.value.replace(/\^/g, '**');
            display.value = eval(expression);
        }
    } catch (error) {
        display.value = "Error";
    }
}
